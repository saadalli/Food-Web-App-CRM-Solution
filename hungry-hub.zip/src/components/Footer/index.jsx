import React from 'react'
import { FaFacebookF, FaInstagram, FaTwitter } from 'react-icons/fa'

const Footer = () => {
  return (
    <footer className="bg-orange text-dark2 py-10">
    <div className="max-w-6xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-6 text-sm">
      {/* Product Section */}
      <div>
        <h3 className="font-semibold mb-3">Product</h3>
        <ul className="space-y-2">
          <li>Lorem Ipsum</li>
          <li>Lorem</li>
          <li>Dolor Sit Amet</li>
          <li>Dolor Lorem</li>
          <li>Ipsum dolor</li>
          <li>Lorem</li>
        </ul>
      </div>

      {/* Explore Section */}
      <div>
        <h3 className="font-semibold mb-3">Explore</h3>
        <ul className="space-y-2">
          <li>Resources</li>
          <li>Blog</li>
          <li>Documents</li>
        </ul>
      </div>

      {/* Community Section */}
      <div>
        <h3 className="font-semibold mb-3">Community</h3>
        <ul className="space-y-2">
          <li>Community Central</li>
          <li>Support</li>
          <li>Help</li>
          <li>My info</li>
        </ul>
      </div>

      {/* Company Section */}
      <div>
        <h3 className="font-semibold mb-3">Company</h3>
        <ul className="space-y-2">
          <li>About us</li>
          <li>Partners</li>
          <li>Customers</li>
          <li>Contact us</li>
        </ul>
      </div>
    </div>

    {/* Branding & Social Links */}
    <div className="text-center mt-8">
      <img src="/assets/darklogo.png" alt="logo" className='mx-auto' />
      <p className="text-xs mt-2">Copyright © 2024 UI UX By Sensive.std</p>

      {/* Social Icons */}
      <div className="flex justify-center space-x-4 mt-4 text-lg">
      <FaFacebookF />
      <FaTwitter />
      <FaInstagram />
      </div>
    </div>
  </footer>
  )
}

export default Footer
