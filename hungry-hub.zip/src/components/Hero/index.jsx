import Image from 'next/image'
import React from 'react'
import Button from '../common/Button'

const HeroSection = () => {
    return (
        <div className='w-full relative'>
            <img src="/assets/circle.png" alt="circle" className='hidden md:block absolute -top-5 right-0' />
            <div className='container px-6 mx-auto relative mt-24 lg:mt-[117px]'>
                <div className='grid grid-cols-1 lg:grid-cols-2 gap-6'>
                    <div className='text-dark2'>
                        <h3 className='text-2xl font-medium text-orange'>Welcome To HungryHub</h3>
                        <h1 className='w-full mt-10 max-w-[581px] text-5xl font-semibold lg:text-[64px]'>Explore The World Of <span className='text-orange'>Culinary</span> Delights </h1>
                        <Button
                            className={'mt-[90px]'}
                            title={'Explore Our Menu'}
                        />
                    </div>
                    <Image
                        height={526}
                        width={580}
                        src={'/assets/heroimg.png'}
                        className='z-10'
                    />
                </div>
            </div>
            <div className='grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center container mx-auto px-6 mt-6'>
                <div>
                    <h1 className='text-2xl mb-9 font-medium text-dark2'>Special Menu</h1>
                    <div className='flex gap-[34px] items-center flex-wrap'>
                        <img src="/assets/spmenu1.png" alt="spmenu" className='min-w-[100px] min-h-[100px] max-h-[100px] rounded-full' />
                        <img src="/assets/spmenu2.png" alt="spmenu" className='min-w-[100px] min-h-[100px] max-h-[100px] rounded-full' />
                        <img src="/assets/spmenu3.png" alt="spmenu" className='min-w-[100px] min-h-[100px] max-h-[100px] rounded-full' />
                        <img src="/assets/spmenu4.png" alt="spmenu" className='min-w-[100px] min-h-[100px] max-h-[100px] rounded-full' />
                    </div>
                </div>
                <div className='relative mt-10'>
                <h1 className='text-2xl mb-9 font-medium text-dark2'>Craving? Click, Order, Enjoy.</h1>
        <p className='text-dark'>Delicious meals delivered right to your doorstep. Explore your favorite restaurants, discover new flavors, and satisfy your cravings with just a few clicks!</p>
        <img src="/assets/Line.png" alt="line" className='absolute hidden lg:block -top-[210px] right-52 !z-0 ' />
                </div>


            </div>
        </div>
    )
}

export default HeroSection
