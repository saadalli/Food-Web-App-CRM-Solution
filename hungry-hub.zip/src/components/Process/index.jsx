import React from 'react'
const steps = [
    {
      number: "01",
      title: "Browse Menu And Select Items",
      description:
        "Customers Can Explore Our Comprehensive Menu And Choose Their Favorite Dishes.",
    },
    {
      number: "02",
      title: "Customize Options (If Applicable)",
      description:
        "If There Are Customization Options Such As Add-Ons, Ingredient Substitutions, Or Special Requests, Customers Can Tailor Their Orders Accordingly.",
    },
    {
      number: "03",
      title: "Add To Cart And Review Order",
      description:
        "After Selecting Items, Customers Can Add Them To Their Shopping Cart And Review Their Order Before Checkout.",
    },
    {
      number: "04",
      title: "Checkout And Payment",
      description:
        "Customers Proceed To The Checkout Process Where They Provide Delivery Information, Choose A Payment Method, And Complete The Payment.",
    },
    {
      number: "05",
      title: "Confirmation And Delivery/Collection",
      description:
        "Upon Successful Payment, Customers Receive An Order Confirmation With Delivery Details Or Pickup Instructions.",
    },
  ];
const Process = () => {
  return (
    <div className='container px-6 mx-auto py-[100px] md:py-[150px] lg:py-[241px]  '>
              <div className="max-w-5xl  py-12 px-4">
      <h2 className="text-3xl font-bold text-gray-900 text-start">
        Our Ordering Process
      </h2>
      <p className="text-start text-gray-500 mt-2">
        Explain How Customers Can Easily And Conveniently Order Food From Your
        Establishment.
      </p>

      <div className="mt-8 space-y-6">
        {steps.map((step, index) => (
          <div key={index} className="flex items-start space-x-16">
            <div className="flex flex-col items-center">
              <div className="w-[100px] h-[100px] bg-orange text-white text-[38px] font-bold rounded-full flex items-center justify-center">
                {step.number}
              </div>
              {index < steps.length - 1 && (
                <img src='/assets/arrow.png' className='' alt='arrow'/>
              )}
            </div>
            <div>
              <h3 className="text-[28px] font-medium text-dark2">{step.title}</h3>
              <p className="text-dark">{step.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
      
      
    </div>
  )
}

export default Process
