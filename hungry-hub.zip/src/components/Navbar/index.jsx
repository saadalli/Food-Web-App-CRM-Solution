'use client'
import Image from 'next/image'
import React, { useState } from 'react'
import { FaTimes, FaBars } from 'react-icons/fa';

const btns=[
    {
        id:1,
        title:"Home"
    },
    {
        id:2,
        title:"About Us"
    },
    {
        id:3,
        title:"Menu"
    },
    {
        id:4,
        title:"Gallery"
    },
    {
        id:5,
        title:"Contact Us"
    },
]
const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
    <div className='container mx-auto bg-white h-[50px] mt-10 lg:mt-[59px] flex justify-between items-center px-6'>
        <Image  height={50} width={216} src="/assets/logo.png" alt="logo" />
        <ul className='list-none hidden lg:flex items-center gap-10 text-xl font-bold text-dark'>
            {btns?.map((btn)=>(
                <li key={btn.id} className=''>{btn.title}</li>
            ))}
        </ul>
        
        <div className='flex items-center h-full gap-10'>

      <button className='h-full hidden sm:block px-5 bg-orange text-white font-medium text-xl rounded-full'>Get Started</button>
      <button
          onClick={toggleSidebar}
          className='lg:hidden text-orange text-2xl focus:outline-none'
          >
           <FaBars  />
        </button>

        </div>
    </div>
    {/* Mobile Sidebar (animated) */}
    <div
        className={`fixed top-0 right-0 h-full w-64 z-50 bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
          isOpen ? '-translate-x-0' : 'translate-x-full'
        } lg:hidden`}
      >
        <button
          onClick={toggleSidebar}
          className='lg:hidden text-orange text-2xl mt-6 ml-6 focus:outline-none'
          >
           <FaTimes  />
        </button>
        <ul className='list-none p-5'>
          {btns?.map((btn) => (
            <li key={btn.id} className='py-3 text-dark text-xl font-bold'>
              {btn.title}
            </li>
          ))}
        </ul>
      </div>
            </>
  )
}

export default Navbar
