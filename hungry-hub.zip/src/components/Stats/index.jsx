import React from 'react'
const stats = [
    { value: "128 +", label: "Catering Services" },
    { value: "2,998 +", label: "Delivery Orders" },
    { value: "892 +", label: "Cuisine Options" },
    { value: "82.98 %", label: "Happy Customers" },
  ];
const Stats = () => {
  return (
    <div className='container mx-auto px-6 py-[100px] md:py-[150px] lg:py-[241px]'>
      <div className="flex  justify-evenly gap-24 text-center flex-wrap">
      {stats.map((stat, index) => (
        <div key={index}>
          <p className=" font-bold text-4xl lg:text-5xl mb-6 text-orange">{stat.value}</p>
          <p className="text-dark text-xl">{stat.label}</p>
        </div>
      ))}
    </div>
    </div>
  )
}

export default Stats
