import React from 'react'

const Button = ({className,onClick,title}) => {
  return (
    <button onClick={onClick} className={`${className} h-[50px] flex justify-center items-center px-5 bg-orange text-white font-medium text-xl rounded-full`}>
      {title}
    </button>
  )
}

export default Button
