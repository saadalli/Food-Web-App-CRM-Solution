import React from 'react'
import { LuArrowRight,LuArrowLeft } from "react-icons/lu";
const Testimonials = () => {
  return (
    <div className='container px-6 mx-auto pb-[100px] md:pb-[150px] lg:pb-[241px] relative'>
              
              <div className=" mx-auto py-12 px-4 text-center">
      <h2 className="text-[52px] font-semibold text-dark2">What Our Clients Say</h2>
      
      <div className="mt-6 text-orange text-6xl">“</div>
      
      <p className="text-dark mt-2 max-w-3xl mx-auto">
        The Food Quality And Taste Exceeded My Expectations. Our Team Lunch Was A Huge Hit Thanks To Your Delicious Dishes!
      </p>

      <div className="mt-4">
        <h3 className="text-lg font-bold text-orange">Sarah Johnson</h3>
        <p className="text-dark">Marketing Manager</p>
      </div>

      {/* Arrows for navigation (non-functional) */}
      <div className='absolute w-full top-20 left-0'>

      <div className="flex justify-between  items-center mt-6">
        <button className="w-[69px] h-[69px] flex items-center justify-center bg-orange text-white rounded-full">
        <LuArrowLeft size={35} />
        </button>
        <button className="w-[69px] h-[69px] flex items-center justify-center bg-orange text-white rounded-full">
        <LuArrowRight size={35} />
        </button>
      </div>
      </div>
    </div>
    </div>
  )
}

export default Testimonials
