'use client'
import React from 'react'
import { FaRegHeart } from 'react-icons/fa';
import { MdOutlineShoppingCartCheckout } from "react-icons/md";
import { PiArrowBendDoubleUpRightBold } from "react-icons/pi";
const foodItems = [
    {
      name: "Italian Herbia",
      price: "$28",
      description: "There Are Many Variations",
      image: "/assets/m1.png",
    },
    {
      name: "Mexican Roll",
      price: "$28",
      description: "There Are Many Variations",
      image: "/assets/m2.png",
    },
    {
      name: "Fetucini Paste",
      price: "$28",
      description: "There Are Many Variations",
      image: "/assets/m3.png",
    },
    {
      name: "Pizzeria Lam",
      price: "$28",
      description: "There Are Many Variations",
      image: "/assets/m4.png",
    },
    {
      name: "Red Sandwich",
      price: "$28",
      description: "There Are Many Variations",
      image: "/assets/m5.png",
    },
    {
      name: "Grilled Chick",
      price: "$28",
      description: "There Are Many Variations",
      image: "/assets/m6.png",
    },
  ];
const Menus = () => {
  return (
    <div className='container px-6 mx-auto pb-[100px] md:pb-[150px] lg:pb-[241px] flex flex-col items-center justify-center'>
        <div className='w-full max-w-[722px]  flex flex-col items-center justify-center mb-24 lg:mb-[116px]'>

      <h3 className='text-4xl lg:text-[52px]  font-semibold text-dark2 mb-12'>About Us</h3>
                <p className='text-dark mb-[68px] text-center  '>We bring your favorite meals to your doorstep with convenience and care. Enjoy fast, reliable service and a wide variety of delicious options.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full mx-auto">
      {foodItems.map((food, index) => (
        <div
          key={index}
          className="border rounded-[20px] shadow-lg py-[34px] px-[22px] bg-[#FDFDFD] border-[#00000040] text-center relative"
        >
          <span className="absolute top-8 left-[22px] bg-orange text-white text-xs px-5 h-[31px] flex justify-center items-center rounded-full">
            Category
          </span>
          <span className="absolute top-8 right-[22px] text-white bg-orange h-[31px] rounded-full flex justify-center items-center w-[31px] text-lg cursor-pointer">
          <FaRegHeart />
          </span>
          <img
            src={food.image}
            alt={food.name}
            className="w-[214px] h-[214px] mt-12 rounded-full mx-auto object-cover"
          />
          <div className='w-full flex items-center justify-between mb-5'>
          <h3 className="text-2xl text-dark2 font-medium mt-4">{food.name}</h3>

          <p className="text-orange font-bold text-[28px] mt-2">{food.price}</p>
          </div>
          <p className="text-dark text-start">{food.description}</p>
          <button className="bg-orange text-white px-6 font-medium py-3 mt-12 rounded-full flex items-center mx-auto gap-2">
            Order Now <span className="text-sm"><MdOutlineShoppingCartCheckout /></span>
          </button>
        </div>
      ))}
    </div>
          <button className="bg-orange text-white px-6 font-medium py-3 mt-20 lg:mt-28  rounded-full flex items-center mx-auto gap-2">
          See All Menu Sehatno <span className="text-sm"><PiArrowBendDoubleUpRightBold /></span>
          </button>
    </div>
  )
}

export default Menus
