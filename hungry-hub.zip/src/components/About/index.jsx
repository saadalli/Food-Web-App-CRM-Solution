'use client'
import Image from 'next/image'
import React from 'react'

const About = () => {
    return (
        <div className='relative w-full'>
            <img src="/assets/circle.png" alt="circle" className='hidden md:block absolute rotate-180 top-16 left-0' />
            <div className='container px-6 mx-auto pb-[100px] md:pb-[150px] lg:pb-[241px] grid grid-cols-1 lg:grid-cols-2 gap-16 items-center'>
                <Image
                    height={533}
                    width={533}
                    src={'/assets/about.png'}
                    className='z-10 rounded-ful '
                />
                <div className='flex flex-col items-center lg:items-start'>
                <h3 className='text-4xl lg:text-[52px]  font-semibold text-dark2'>About Us</h3>
                <h5 className='font-medium text-xl text-orange mb-6 mt-16'>Restaurant Story</h5>
                <p className='text-dark mb-[68px] text-center lg:text-start'>We bring your favorite meals to your doorstep with convenience and care. Enjoy fast, reliable service and a wide variety of delicious options.</p>
                <h3 className='font-medium text-xl text-orange mb-[68px] '>Awards and Recognition:</h3>

                <div className='flex items-center justify-center lg:justify-start gap-12 flex-wrap 2xl:flex-nowrap '>
                    <div className='p-7 rounded-[10px] flex items-center w-fit flex-col gap-6'>
                        <img src="/assets/diamond.svg" alt="svg"  className='w-[35px] h-[35px]' />
                        <h1 className='font-medium text-dark text-nowrap'>TOP RATED</h1>

                    </div>
                    <div className='p-7 rounded-[10px] bg-orange flex items-center w-fit flex-col gap-6'>
                        <img src="/assets/finance.svg" alt="svg"  className='w-[35px] h-[35px]' />
                        <h1 className='font-medium text-white text-nowrap'>TRUSTED CHOICE</h1>

                    </div>
                    <div className='p-7 rounded-[10px] flex  items-center w-fit flex-col gap-6'>
                        <img src="/assets/objects.svg" alt="svg"  className='w-[35px] h-[35px]' />
                        <h1 className='font-medium text-dark text-nowrap'>CUSTOMER FAVOURITE</h1>

                    </div>
                </div>

                </div>
            </div>

        </div>
    )
}

export default About
