import About from "@/components/About";
import Footer from "@/components/Footer";
import HeroSection from "@/components/Hero";
import Menus from "@/components/Menus";
import Navbar from "@/components/Navbar";
import Offer from "@/components/Offer";
import Process from "@/components/Process";
import Stats from "@/components/Stats";
import Testimonials from "@/components/Testimonials";
import Image from "next/image";

export default function Home() {
  return (
    <>

     <Navbar/>
     <HeroSection/>
     <Stats/>
     <About/>
     <Menus/>
     <Offer/>
     <Process/>
     <Testimonials/>
     <Footer/>
    </>
  );
}
